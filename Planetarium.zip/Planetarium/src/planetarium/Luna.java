package planetarium;

public class Luna {
    private String nome;
    private String id;
    private float massa;
    private int posizioneX;
    private int posizioneY;
    private double raggio; // distanza dal pianeta
    private double corona; // distanza dalla stella
    private Pianeta pianetaPadre;

    // Costruttore completo
    public Luna(String nome, String id, float massa, int posizioneX, int posizioneY,
                double raggio, double corona, Pianeta pianetaPadre) {
        this.nome = nome;
        this.id = id;
        this.massa = massa;
        this.posizioneX = posizioneX;
        this.posizioneY = posizioneY;
        this.raggio = raggio;
        this.corona = corona;
        this.pianetaPadre = pianetaPadre;
    }

    // Costruttore vuoto
    public Luna() {}

    // Metodi getter e setter
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public float getMassa() { return massa; }
    public void setMassa(float massa) { this.massa = massa; }

    public String getPosizione() {
        return "( " + posizioneX + ", " + posizioneY + " )";
    }
    public void setPosizione(int x, int y) {
        this.posizioneX = x;
        this.posizioneY = y;
        if (pianetaPadre != null) {
            // Calcola distanza dal pianeta padre
            this.raggio = Math.sqrt(Math.pow(x - pianetaPadre.getPosizioneX(), 2) +
                    Math.pow(y - pianetaPadre.getPosizioneY(), 2));
            // Calcola distanza dalla stella
            this.corona = Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2));
        }
    }

    public int getPosizioneX() { return posizioneX; }

    public int getPosizioneY() { return posizioneY; }

    public double getRaggio() { return raggio; }

    public double getCorona() { return corona; }

    public Pianeta getPianetaPadre() { return pianetaPadre; }
    public void setPianetaPadre(Pianeta pianetaPadre) { this.pianetaPadre = pianetaPadre; }

    public double[] calcolaCoronaCircolare() {
        if (pianetaPadre == null) {
            return new double[]{0, 0};
        }

        double raggioPianeta = pianetaPadre.getRaggio();
        double raggioLuna = this.raggio;

        double raggioMin = Math.abs(raggioPianeta - raggioLuna);
        double raggioMax = raggioPianeta + raggioLuna;

        return new double[]{raggioMin, raggioMax};
    }

    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("-----------------------------------\n");
        sb.append("Luna [nome=").append(nome);
        sb.append(", \nid=").append(id);
        sb.append(", \nmassa=").append(massa);
        sb.append(", \nposizione=(").append(posizioneX).append(",").append(posizioneY).append(")");
        sb.append(", \nraggio=").append(raggio);
        sb.append(", \ncorona=").append(corona);
        sb.append(", \npianetaPadre=").append(pianetaPadre != null ? pianetaPadre.getNome() : "null");
        sb.append("]");
        sb.append("\n-------------------------------------\n");
        return sb.toString();
    }
}