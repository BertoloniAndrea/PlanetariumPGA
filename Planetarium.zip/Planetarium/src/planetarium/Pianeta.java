package planetarium;

import java.util.*;

/**
 * Classe che rappresenta un pianeta in un sistema planetario.
 * Contiene informazioni sul pianeta e gestisce le lune che gli orbitano attorno.
 */
public class Pianeta {
    private String nome;
    private String id;
    private float massa;
    private int posizioneX;
    private int posizioneY;
    private double raggio;
    private ArrayList<Luna> lune = new ArrayList<>();

    /**
     * Costruttore completo per il pianeta
     * @param nome nome del pianeta
     * @param id identificativo univoco
     * @param massa massa del pianeta
     * @param posizioneX coordinata X
     * @param posizioneY coordinata Y
     * @param lune lista di lune orbitanti (può essere null)
     */
    public Pianeta(String nome, String id, float massa, int posizioneX, int posizioneY, ArrayList<Luna> lune) {
        this.nome = nome;
        this.id = id;
        this.massa = massa;
        this.posizioneX = posizioneX;
        this.posizioneY = posizioneY;
        this.lune = lune != null ? lune : new ArrayList<>();
        this.raggio = Math.sqrt(Math.pow(posizioneX, 2) + Math.pow(posizioneY, 2));
    }

    /**
     * Costruttore vuoto che inizializza la lista delle lune
     */
    public Pianeta() {}

    /**
     * Restituisce il nome del pianeta
     * @return nome del pianeta
     */
    public String getNome() { return nome; }

    /**
     * Imposta il nome del pianeta
     * @param nome nuovo nome da impostare
     */
    public void setNome(String nome) { this.nome = nome; }

    /**
     * Restituisce l'ID del pianeta
     * @return ID del pianeta
     */
    public String getId() { return id; }

    /**
     * Imposta l'ID del pianeta
     * @param id nuovo ID da impostare
     */
    public void setId(String id) { this.id = id; }

    /**
     * Restituisce la massa del pianeta
     * @return massa del pianeta
     */
    public float getMassa() { return massa; }

    /**
     * Imposta la massa del pianeta
     * @param massa nuova massa da impostare
     */
    public void setMassa(float massa) { this.massa = massa; }

    /**
     * Restituisce la posizione formattata del pianeta
     * @return stringa con le coordinate (X, Y)
     */
    public String getPosizione() {
        return "( " + posizioneX + ", " + posizioneY + " )";
    }

    /**
     * Imposta la posizione del pianeta e ricalcola il raggio orbitale
     * @param x nuova coordinata X
     * @param y nuova coordinata Y
     */
    public void setPosizione(int x, int y) {
        this.posizioneX = x;
        this.posizioneY = y;
        this.raggio = Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2));
    }

    /**
     * Restituisce la coordinata X del pianeta
     * @return coordinata X
     */
    public int getPosizioneX() { return posizioneX; }

    /**
     * Restituisce la coordinata Y del pianeta
     * @return coordinata Y
     */
    public int getPosizioneY() { return posizioneY; }

    /**
     * Restituisce il raggio orbitale del pianeta (distanza dalla stella)
     * @return raggio orbitale
     */
    public double getRaggio() { return raggio; }

    /**
     * Restituisce la lista delle lune orbitanti
     * @return ArrayList di Luna
     */
    public ArrayList<Luna> getLune() { return lune; }

    /**
     * Imposta la lista delle lune orbitanti
     * @param lune nuova lista di lune (può essere null)
     */
    public void setLune(ArrayList<Luna> lune) {
        this.lune = lune != null ? lune : new ArrayList<>();
    }

    /**
     * Override del metodo toString per la rappresentazione testuale del pianeta
     * @return stringa descrittiva del pianeta
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("-------------------------------------\n");
        sb.append("Pianeta: ").append(nome).append("\n");
        sb.append("ID: ").append(id).append("\n");
        sb.append("Massa: ").append(massa).append("\n");
        sb.append("Posizione: (").append(posizioneX).append(", ").append(posizioneY).append(")\n");
        sb.append("Raggio orbitale: ").append(raggio).append("\n");
        sb.append("Lune: ");
        if (lune.isEmpty()) {
            sb.append("Nessuna luna");
        } else {
            for (Luna l : lune) {
                sb.append("\n- ").append(l.getNome()).append(" (").append(l.getId()).append(")");
            }
        }
        sb.append("\n-------------------------------------\n");
        return sb.toString();
    }

    /**
     * Aggiunge una luna al pianeta
     * @param luna la luna da aggiungere
     * @return true se l'aggiunta è avvenuta con successo, false altrimenti
     * @throws IllegalArgumentException se la luna è null o già presente
     */
    public boolean aggiungiLuna(Luna luna) {
        if (lune.size() >= 5000) {
            return false;
        }
        if (luna != null && !lune.contains(luna)) {
            String idLuna = this.nome.substring(0, 3).toUpperCase()
                    + "LU" + (lune.size() + 1);
            luna.setId(idLuna);
            luna.setPianetaPadre(this);
            lune.add(luna);
            return true;
        }
        return false;
    }
}