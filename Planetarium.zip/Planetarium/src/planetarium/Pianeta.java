package planetarium;

import java.util.*;

public class Pianeta {
    private String nome;
    private String id;
    private float massa;
    private int posizioneX;
    private int posizioneY;
    private double raggio;
    private ArrayList<Luna> lune = new ArrayList<>();

    public Pianeta(String nome, String id, float massa, int posizioneX, int posizioneY, ArrayList<Luna> lune) {
        this.nome = nome;
        this.id = id;
        this.massa = massa;
        this.posizioneX = posizioneX;
        this.posizioneY = posizioneY;
        this.lune = lune != null ? lune : new ArrayList<>();
        this.raggio = Math.sqrt(Math.pow(posizioneX, 2) + Math.pow(posizioneY, 2));
    }

    public Pianeta() {}

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public float getMassa() { return massa; }
    public void setMassa(float massa) { this.massa = massa; }

    public String getPosizione() {
        return "( " + posizioneX + ", " + posizioneY + " )";
    }
    public void setPosizione(int x, int y) {
        this.posizioneX = x;
        this.posizioneY = y;
        this.raggio = Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2));
    }

    public int getPosizioneX() { return posizioneX; }

    public int getPosizioneY() { return posizioneY; }

    public double getRaggio() { return raggio; }

    public ArrayList<Luna> getLune() { return lune; }
    public void setLune(ArrayList<Luna> lune) { this.lune = lune != null ? lune : new ArrayList<>(); }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("-------------------------------------\n");
        sb.append("Pianeta: ").append(nome).append("\n");
        sb.append("ID: ").append(id).append("\n");
        sb.append("Massa: ").append(massa).append("\n");
        sb.append("Posizione: (").append(posizioneX).append(", ").append(posizioneY).append(")\n");
        sb.append("Raggio orbitale: ").append(raggio).append("\n");
        sb.append("Lune: ");
        if (lune.isEmpty()) {
            sb.append("Nessuna luna");
        } else {
            for (Luna l : lune) {
                sb.append("\n- ").append(l.getNome()).append(" (").append(l.getId()).append(")");
            }
        }
        sb.append("\n-------------------------------------\n");
        return sb.toString();
    }

    public boolean aggiungiLuna(Luna luna) {
        if (lune.size() >= 5000) {
            return false;
        }
        if (luna != null && !lune.contains(luna)) {
            String idLuna = this.nome.substring(0, 3).toUpperCase()
                    + "LU" + (lune.size() + 1);
            luna.setId(idLuna);
            luna.setPianetaPadre(this);
            lune.add(luna);
            return true;
        }
        return false;
    }
}