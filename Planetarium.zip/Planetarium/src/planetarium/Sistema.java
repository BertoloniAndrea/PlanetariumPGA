package planetarium;

import java.util.*;

/**
 * Classe principale che gestisce il sistema planetario.
 * Fornisce un'interfaccia utente per la gestione, ricerca e visualizzazione
 * degli astri (stelle, pianeti e lune) nel sistema.
 */
public class Sistema {

    private static Stella stella;

    /**
     * Restituisce l'oggetto Stella del sistema
     * @return l'oggetto Stella corrente
     */
    public Stella getStella() { return stella; }

    /**
     * Imposta l'oggetto Stella del sistema
     * @param stella l'oggetto Stella da impostare
     */
    public void setStella(Stella stella) { this.stella = stella; }

    /**
     * Metodo di inizializzazione del sistema.
     * Configura la stella principale con nome e massa forniti dall'utente.
     */
    public static void start() {
        Scanner scanner = new Scanner(System.in);
        stella = new Stella();

        String nome;
        double massa;

        System.out.println("--- Benvenuto nella console di gestione del Sistema! ---");
        System.out.println("--- ...Configurazione iniziale... ---");
        do {
            System.out.print("Inserisci il nome della nostra stella: ");
            nome = scanner.nextLine();
            if (nome.length() < 3) {
                System.out.println("Attenzione! Il nome della stella deve essere di almeno 3 caratteri. Reinserire l'input.");
            }
        }while(nome.length() < 3);
        System.out.print("Inserisci la massa della stella: ");

        do {
            massa = scanner.nextDouble();
            if (massa < 50 || massa > 500) {
                System.out.println("Attenzione! Le massa inserita ha un problema! Inserire un valore compreso tra [50, 500]");
            }
        }while(massa < 50 || massa > 500);

        stella.setNome(nome);
        stella.setMassa(massa);
        stella.setPosizione(0, 0);

        System.out.println("------------------------------------------------------------------");

        menuPrincipale();
    }

    /**
     * Menu principale del sistema.
     * Offre opzioni per gestione, ricerca, visualizzazione e calcoli.
     */
    public static void menuPrincipale() {
        Scanner scanner = new Scanner(System.in);

        int scelta;
        String id;

        System.out.println("-------------------------------------------------------");
        System.out.println("--- Benvenuto nella console gestionale del Sistema! ---");
        System.out.println("-------------------------------------------------------");
        System.out.println("[1] | Apri la console di gestione");
        System.out.println("[2] | Apri la console di ricerca");
        System.out.println("[3] | Apri la console di visualizzazione");
        System.out.println("[4] | Apri la console per il calcolo del centro di massa");
        System.out.println("[0] | Chiudi la console");
        System.out.print("> ");

        do {
            scelta = scanner.nextInt();
            if (scelta < 0 || scelta > 4) {
                System.out.println("!Attenzione! Hai inserito un valore sbagliato. Consulta il menu della console per scegliere l'opzione che trovi piu' corretta.");
            }
        }while(scelta < 0 || scelta > 4);

        switch (scelta) {
            case 0:
                return;

            case 1:
                menuGestione();
                break;

            case 2:
                menuRicerca();
                menuPrincipale();
                break;

            case 3:
                menuVisualizzazione();
                menuPrincipale();
                break;

            case 4:
                stella.centroDiMassa();
                System.out.println("");
                menuPrincipale();
                break;

            default:
        }
    }

    /**
     * Menu per la ricerca di un astro nel sistema.
     * Chiede all'utente l'ID dell'astro da ricercare e ne mostra i dettagli.
     */
    private static void menuRicerca() {
        Scanner scanner = new Scanner(System.in);

        String id;

        System.out.println("--- Hai selezionato [2] | Apri la console di ricerca. ---");
        System.out.println("--- Hai aperto la console di ricerca. ---");
        System.out.println("----------------------------------------------------------");
        System.out.print("Inserisci l'identificativo dell'astro che si vuole ricercare: ");
        id = scanner.nextLine().toUpperCase();
        stella.stampaAstro(id);
    }

    /**
     * Menu principale per la gestione del sistema.
     * Offre opzioni per aggiungere o rimuovere astri.
     */
    private static void menuGestione() {
        Scanner scanner = new Scanner(System.in);

        int scelta;

        System.out.println("--- Hai selezionato [1] | Apri la console di gestione. ---");
        System.out.println("--- Hai aperto la console di gestione. ---");
        System.out.println("----------------------------------------------------------");
        System.out.println("[1] | Apri la console di aggiunta");
        System.out.println("[2] | Apri la console di rimozione");
        System.out.println("[3] | Ritorna alla console principale");
        System.out.println("[0] | Chiudi la console");
        System.out.print("> ");

        do {
            scelta = scanner.nextInt();
            if (scelta < 0 || scelta > 3) {
                System.out.println("!Attenzione! Hai inserito un valore sbagliato. Consulta il menu della console per scegliere l'opzione che trovi piu' corretta.");
            }
        }while(scelta < 0 || scelta > 3);

        switch (scelta) {
            case 0:
                return;

            case 1:
                menuGestioneAggiunta();
                break;

            case 2:
                menuRimozione();
                break;

            case 3:
                menuPrincipale();
                break;

            default:
        }
    }

    /**
     * Menu per la rimozione di astri dal sistema.
     * Permette di rimuovere pianeti o lune.
     */
    private static void menuRimozione() {
        Scanner scanner = new Scanner(System.in);

        int scelta;
        String idPianeta, idLuna;

        System.out.println("--- Hai selezionato [2] | Apri la console di rimozione. ---");
        System.out.println("--- Hai aperto la console di rimozione. ---");
        System.out.println("----------------------------------------------------------");
        System.out.println("[1] | Rimuovi un pianeta");
        System.out.println("[2] | Rimuovi una luna");
        System.out.println("[3] | Ritorna alla console di gestione");
        System.out.println("[4] | Ritorna alla console principale");
        System.out.println("[0] | Chiudi la console");
        System.out.print("> ");

        do {
            scelta = scanner.nextInt();
            if (scelta < 0 || scelta > 4) {
                System.out.println("!Attenzione! Hai inserito un valore sbagliato. Consulta il menu della console per scegliere l'opzione che trovi piu' corretta.");
            }
        }while(scelta < 0 || scelta > 4);

        switch (scelta) {
            case 0:
                return;

            case 1:
                System.out.println("--- Hai selezionato [1] | Rimozione di un pianeta ---");
                System.out.println("--- Compila il seguente form per la rimozione di un pianeta ---");
                System.out.println("---------------------------------------------------------------");
                System.out.print("Inserisci l'identificativo del pianeta da rimuovere dal sistema: ");
                scanner.nextLine();
                idPianeta = scanner.nextLine().toUpperCase();
                if (stella.ricercaAstro(idPianeta) == false) {
                    System.out.println("Il pianeta con l'identificativo {" + idPianeta + "} non esiste. Impossibile procedere con la rimozione.");
                }else{
                    System.out.println("Il pianeta con l'identificativo {" + idPianeta + "} è stato trovato con successo.");
                    System.out.println("Proseguo con la sua rimozione dal sistema...");
                    stella.rimuoviPianeta(idPianeta);
                }
                menuPrincipale();
                break;

            case 2:
                System.out.println("--- Hai selezionato [2] | Rimozione di una luna ---");
                System.out.println("--- Compila il seguente form per la rimozione di una luna ---");
                System.out.println("---------------------------------------------------------------");
                System.out.print("Inserisci l'identificativo del pianeta attorno al quale orbita la luna da rimuovere: ");
                idPianeta = scanner.nextLine().toUpperCase();
                System.out.print("Inserisci l'identificativo della luna da rimuovere dal sistema: ");
                idLuna = scanner.nextLine().toUpperCase();
                if (!stella.ricercaAstro(idLuna)) {
                    System.out.println("La luna con l'identificativo {" + idLuna + "} non esiste. Impossibile procedere con la rimozione.");
                }else{
                    System.out.println("La luna con l'identificativo {" + idLuna + "} è stata trovata con successo.");
                    System.out.println("Proseguo con la sua rimozione dal sistema...");
                    stella.rimuoviLuna(idPianeta, idLuna);
                }
                menuPrincipale();
                break;

            case 3:
                menuGestione();
                break;

            case 4:
                menuPrincipale();
                break;

            default:
        }
    }

    /**
     * Menu per l'aggiunta di nuovi astri al sistema.
     * Permette di aggiungere pianeti o lune.
     */
    private static void menuGestioneAggiunta() {
        Scanner scanner = new Scanner(System.in);

        Pianeta pianeta = new Pianeta();
        Luna luna = new Luna();

        int scelta;
        String idPianeta;

        System.out.println("--- Hai selezionato [1] | Apri la console di aggiunta. ---");
        System.out.println("--- Hai aperto la console di aggiunta. ---");
        System.out.println("----------------------------------------------------------");
        System.out.println("[1] | Aggiungi un pianeta");
        System.out.println("[2] | Aggiungi una luna");
        System.out.println("[3] | Ritorna alla console di gestione");
        System.out.println("[4] | Ritorna alla console principale");
        System.out.println("[0] | Chiudi la console");
        System.out.print("> ");

        do {
            scelta = scanner.nextInt();
            if (scelta < 0 || scelta > 4) {
                System.out.println("!Attenzione! Hai inserito un valore sbagliato. Consulta il menu della console per scegliere l'opzione che trovi piu' corretta.");
            }
        }while(scelta < 0 || scelta > 4);

        switch (scelta) {
            case 0:
                return;

            case 1:
                pianeta = formDatiPianeta();
                stella.aggiungiPianeta(pianeta);
                menuPrincipale();
                break;

            case 2:
                luna = formDatiLuna();
                if (luna != null) {
                    menuPrincipale();
                }
                menuPrincipale();
                break;

            case 3:
                menuGestione();
                break;

            case 4:
                menuPrincipale();
                break;

            default:
        }
    }

    /**
     * Menu per la visualizzazione degli astri nel sistema.
     * Permette di visualizzare dettagli di pianeti o lune.
     */
    private static void menuVisualizzazione() {
        Scanner scanner = new Scanner(System.in);

        int scelta;

        System.out.println("--- Hai selezionato [3] | Apri la console di visualizzazione. ---");
        System.out.println("--- Hai aperto la console di visualizzazione. ---");
        System.out.println("----------------------------------------------------------");
        System.out.println("[1] | Visualizzazione di un pianeta");
        System.out.println("[2] | Visualizzazione di una luna");
        System.out.println("[3] | Ritorna alla console principale");
        System.out.println("[0] | Chiudi la console");
        System.out.print("> ");

        do {
            scelta = scanner.nextInt();
            if (scelta < 0 || scelta > 3) {
                System.out.println("!Attenzione! Hai inserito un valore sbagliato. Consulta il menu della console per scegliere l'opzione che trovi piu' corretta.");
            }
        }while(scelta < 0 || scelta > 3);

        String id;

        switch (scelta) {
            case 0:
                return;

            case 1:
                System.out.println("Visualizzazione di un pianeta");
                System.out.print("Inserire identificativo pianeta: ");
                scanner.nextLine();
                id = scanner.nextLine().toUpperCase();
                stella.stampaAstro(id);
                break;

            case 2:
                System.out.println("Visualizzazione di una luna");
                System.out.print("Inserire identificativo luna: ");
                scanner.nextLine();
                id = scanner.nextLine().toUpperCase();
                stella.stampaAstro(id);
                break;

            case 3:
                menuPrincipale();
                break;

            default:
        }
    }

    /**
     * Form per l'inserimento dei dati di un nuovo pianeta.
     * @return l'oggetto Pianeta creato con i dati inseriti dall'utente
     */
    private static Pianeta formDatiPianeta() {
        Scanner scanner = new Scanner(System.in);

        Pianeta pianetaFinal = new Pianeta();

        String nome;
        float massa;
        int posizioneX, posizioneY;

        System.out.println("--- Hai selezionato [1] | Aggiunta di un pianeta. ---");
        System.out.println("--- Compila il seguente form per l'inserimento dei dati del pianeta. ---");
        System.out.println("------------------------------------------------------------------------");
        System.out.print("Inserire un nome per il pianeta: ");
        nome = scanner.nextLine();
        System.out.print("Inserire la massa del pianeta: ");
        do {
            massa = scanner.nextFloat();
            if (massa > (stella.getMassa()/2)) {
                System.out.println("Attenzione! La massa del pianeta deve essere minore del 50% della massa della stella.");
            }
        }while(massa > (stella.getMassa()/2));
        do {
            System.out.print("Inserire la coordinata X del pianeta: ");
            posizioneX = scanner.nextInt();
            System.out.print("Inserire la coordinata Y del pianeta: ");
            posizioneY = scanner.nextInt();
            if (posizioneX == 0 && posizioneY == 0) {
                System.out.println("Attenzione! Il pianeta non può essere nella stessa posizione della stella!");
            }
        }while(posizioneX == 0 && posizioneY == 0);

        pianetaFinal.setNome(nome);
        pianetaFinal.setMassa(massa);
        pianetaFinal.setPosizione(posizioneX, posizioneY);

        return pianetaFinal;
    }

    /**
     * Form per l'inserimento dei dati di una nuova luna.
     * @return l'oggetto Luna creato con i dati inseriti dall'utente, o null se l'inserimento fallisce
     */
    private static Luna formDatiLuna() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("--- Hai selezionato [2] | Aggiunta di una luna. ---");
        System.out.println("--- Compila il seguente form per l'inserimento dei dati della luna. ---");
        System.out.println("------------------------------------------------------------------------");

        // Prima chiedi a quale pianeta associare la luna
        System.out.print("Inserisci l'ID del pianeta attorno a cui orbita la luna: ");
        String idPianeta = scanner.nextLine();

        // Cerca il pianeta padre
        Pianeta pianetaPadre = null;
        for (Pianeta p : stella.getPianeti()) {
            if (p.getId().equals(idPianeta)) {
                pianetaPadre = p;
                break;
            }
        }

        if (pianetaPadre == null) {
            System.out.println("Pianeta non trovato!");
            return null;
        }

        // Ora raccogli i dati della luna
        System.out.print("Inserire un nome per la luna: ");
        String nome = scanner.nextLine();

        System.out.print("Inserire la massa della luna: ");
        float massa;
        do {
            massa = scanner.nextFloat();
            if (massa > (pianetaPadre.getMassa()/2)) {
                System.out.println("Attenzione! La massa della luna deve essere minore del 50% della massa del pianeta.");
            }
        } while(massa > (pianetaPadre.getMassa()/2));

        int posizioneX, posizioneY;
        do {
            System.out.print("Inserire la coordinata X della luna: ");
            posizioneX = scanner.nextInt();
            System.out.print("Inserire la coordinata Y della luna: ");
            posizioneY = scanner.nextInt();
            if (posizioneX == pianetaPadre.getPosizioneX() && posizioneY == pianetaPadre.getPosizioneY()) {
                System.out.println("Attenzione! La luna non può essere nella stessa posizione del pianeta!");
            }
        } while(posizioneX == pianetaPadre.getPosizioneX() && posizioneY == pianetaPadre.getPosizioneY());

        // Crea la luna con tutti i parametri necessari
        Luna luna = new Luna();
        luna.setNome(nome);
        luna.setMassa(massa);
        luna.setPianetaPadre(pianetaPadre);  // IMPORTANTE: setta prima il pianeta padre
        luna.setPosizione(posizioneX, posizioneY); // Ora può calcolare raggio e corona

        // Aggiungi la luna al pianeta
        if (stella.aggiungiLuna(idPianeta, luna)) {
            System.out.println("Luna aggiunta con successo!");
            return luna;
        } else {
            System.out.println("Errore nell'aggiunta della luna!");
            return null;
        }
    }
}