package planetarium;

import java.util.ArrayList;

public class Stella {
    private double massa;
    private int posizioneX;
    private int posizioneY;
    private String id;
    private String nome;
    private ArrayList<Pianeta> pianeti = new ArrayList<>();

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public double getMassa() { return massa; }
    public void setMassa(double massa) { this.massa = massa; }

    public String getPosizione() {
        return "( " + posizioneX + ", " + posizioneY + " )";
    }
    public void setPosizione(int x, int y) {
        this.posizioneX = x;
        this.posizioneY = y;
    }

    public int getPosizioneX() { return posizioneX; }
    public int getPosizioneY() { return posizioneY; }

    public void setPosizioneX(int x) { this.posizioneX = x; }
    public void setPosizioneY(int y) { this.posizioneY = y; }

    public ArrayList<Pianeta> getPianeti() { return pianeti; }
    public void setPianeti(ArrayList<Pianeta> pianeti) { this.pianeti = pianeti; }

    public Stella(float massa, int posizioneX, int posizioneY, String id, String nome, ArrayList<Pianeta> pianeti) {
        this.massa = massa;
        this.posizioneX = posizioneX;
        this.posizioneY = posizioneY;
        this.id = id;
        this.nome = nome;
        this.pianeti = pianeti;
    }

    public Stella() {
        this.pianeti = new ArrayList<>();
    }

    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("Stella: ").append(nome)
                .append(" (").append(id).append(")")
                .append(", Massa: ").append(massa)
                .append(", Posizione: (").append(posizioneX)
                .append(", ").append(posizioneY).append(")")
                .append(", Pianeti orbitanti: [");

        if (!pianeti.isEmpty()) {
            for (int i = 0; i < pianeti.size(); i++) {
                if (i > 0) {
                    sb.append(", ");
                }
                sb.append(pianeti.get(i).getId());
            }
        } else {
            sb.append("Nessun pianeta");
        }

        sb.append("]");
        return sb.toString();
    }

    public boolean aggiungiPianeta(Pianeta pianeta) {
        if (pianeti.size() >= 26000) {
            return false;
        }
        if (pianeta != null && !pianeti.contains(pianeta)) {
            String idPianeta = this.nome.substring(0, Math.min(3, this.nome.length())).toUpperCase()
                    + "PI" + (pianeti.size() + 1);
            pianeta.setId(idPianeta);
            pianeti.add(pianeta);
            return true;
        }
        return false;
    }

    public boolean aggiungiLuna(String codicePianeta, Luna luna) {
        for (Pianeta p : pianeti) {
            if (p.getId().equals(codicePianeta)) {
                return p.aggiungiLuna(luna);
            }
        }
        return false;
    }

    public void rimuoviPianeta(String idPianeta) {
        for (int i = 0; i < pianeti.size(); i++) {
            if (pianeti.get(i).getId().equals(idPianeta)) {
                pianeti.remove(i);
                return;
            }
        }
        System.out.println("Nessun pianeta trovato con ID: " + idPianeta);
    }

    public void rimuoviLuna(String idPianeta, String idLuna) {
        for (Pianeta p : pianeti) {
            if (p.getId().equals(idPianeta)) {
                for (int j = 0; j < p.getLune().size(); j++) {
                    if (p.getLune().get(j).getId().equals(idLuna)) {
                        p.getLune().remove(j);
                        return;
                    }
                }
            }
        }
        System.out.println("Nessuna luna trovata con ID: " + idLuna + " per il pianeta: " + idPianeta);
    }

    public void centroDiMassa() {
        double sommaMassa = massa;
        double sommaPosizioneX = posizioneX * massa; // Correggi qui
        double sommaPosizioneY = posizioneY * massa;

        for (Pianeta pianeta : pianeti) {
            sommaMassa += pianeta.getMassa();
            sommaPosizioneX += (pianeta.getMassa() * pianeta.getPosizioneX());
            sommaPosizioneY += (pianeta.getMassa() * pianeta.getPosizioneY());

            for (Luna luna : pianeta.getLune()) {
                sommaMassa += luna.getMassa();
                sommaPosizioneX += (luna.getMassa() * luna.getPosizioneX());
                sommaPosizioneY += (luna.getMassa() * luna.getPosizioneY());
            }
        }

        double centroX = sommaPosizioneX / sommaMassa;
        double centroY = sommaPosizioneY / sommaMassa;
        System.out.println("Il centro di massa e': (" + centroX + ", " + centroY + ")");
    }

    public void verificaCollisioni() {
        // Collisioni tra pianeti
        colPianeti();

        // Collisioni tra lune dello stesso pianeta
        for (Pianeta p : pianeti) {
            colLune(p);
        }

        // Collisioni tra lune di pianeti diversi
        colPianetaLuna();
    }

    private void colPianeti() {
        for (int i = 0; i < pianeti.size(); i++) {
            for (int j = i + 1; j < pianeti.size(); j++) {
                Pianeta p1 = pianeti.get(i);
                Pianeta p2 = pianeti.get(j);
                if (Math.abs(p1.getRaggio() - p2.getRaggio()) < 0.001) {
                    System.out.println("[COLLISIONE] Pianeti " + p1.getNome() +
                            " e " + p2.getNome() + " hanno lo stesso raggio orbitale!");
                }
            }
        }
    }

    private void colLune(Pianeta pianeta) {
        ArrayList<Luna> lune = pianeta.getLune();
        for (int i = 0; i < lune.size(); i++) {
            for (int j = i + 1; j < lune.size(); j++) {
                Luna l1 = lune.get(i);
                Luna l2 = lune.get(j);
                if (Math.abs(l1.getRaggio() - l2.getRaggio()) < 0.001) {
                    System.out.println("[COLLISIONE] Lune " + l1.getNome() +
                            " e " + l2.getNome() + " orbitano alla stessa distanza!");
                }
            }
        }
    }

    private void colPianetaLuna() {
        for (Pianeta p : pianeti) {
            for (Luna l : p.getLune()) {
                double[] corona = l.calcolaCoronaCircolare();
                for (Pianeta altroP : pianeti) {
                    if (!p.equals(altroP) &&
                            altroP.getRaggio() >= corona[0] &&
                            altroP.getRaggio() <= corona[1]) {
                        System.out.println("[COLLISIONE] La luna " + l.getNome() +
                                " del pianeta " + p.getNome() +
                                " potrebbe collidere con il pianeta " + altroP.getNome());
                    }
                }
            }
        }
    }


    /**
     Verifica se un astro esiste nel sistema
     @param id L'identificativo dell'astro da cercare
     @return true se l'astro è stato trovato, false altrimenti
     */
    public boolean ricercaAstro(String id) {
        if (id == null || id.length() < 5) return false;

        String tipo = id.substring(3, 5);

        if (tipo.equals("PI")) {
            for (Pianeta p : pianeti) {
                if (p.getId().equals(id)) return true;
            }
        }
        else if (tipo.equals("LU")) {
            String prefissoPianeta = id.substring(0, 3);
            for (Pianeta p : pianeti) {
                if (p.getId().startsWith(prefissoPianeta)) {
                    for (Luna l : p.getLune()) {
                        if (l.getId().equals(id)) return true;
                    }
                }
            }
        }
        return false;
    }

    public String stampaAstro(String id) {
        if (!ricercaAstro(id)) return "Nessun astro trovato con ID: " + id;

        String tipo = id.substring(3, 5);
        String prefissoPianeta = id.substring(0, 3);

        if (tipo.equals("PI")) {
            for (Pianeta p : pianeti) {
                if (p.getId().equals(id)) return p.toString();
            }
        }
        else if (tipo.equals("LU")) {
            for (Pianeta p : pianeti) {
                if (p.getId().startsWith(prefissoPianeta)) {  // Controlla l'ID del pianeta
                    for (Luna l : p.getLune()) {
                        if (l.getId().equals(id)) return l.toString();
                    }
                }
            }
        }
        return "ID non valido";
    }


    public void calcolaRotta(String idPartenza, String idArrivo) {


    }

    private String getPianetaPadre(String idLuna) {
        for (Pianeta p : pianeti) {
            for (Luna l : p.getLune()) {
                if (l.getId().equals(idLuna)) {
                    return p.getId();
                }
            }
        }
        return null;
    }

    private double calcolaDistanza(String id1, String id2) {
        // Se uno dei due è la stella centrale
        if (id1.equals(this.id)) {
            return distanzaDallaStella(id2);
        }
        if (id2.equals(this.id)) {
            return distanzaDallaStella(id1);
        }

        // Se entrambi sono lune
        if (id1.substring(3, 5).equals("LU") && id2.substring(3, 5).equals("LU")) {
            Luna luna1 = (Luna)ottieniAstro(id1);
            Luna luna2 = (Luna)ottieniAstro(id2);
            return Math.abs(luna1.getRaggio() - luna2.getRaggio());
        }


        return 1.0; // Valore di default
    }

    private double distanzaDallaStella(String idAstro) {
        Object astro = ottieniAstro(idAstro);
        if (astro instanceof Pianeta) {
            return ((Pianeta)astro).getRaggio();
        } else if (astro instanceof Luna) {
            return ((Luna)astro).getCorona();
        }
        return 0.0;
    }

    private String stampaNome(String id) {
        if (id.equals(this.id)) {
            return this.nome;
        }

        for (Pianeta p : pianeti) {
            if (p.getId().equals(id)) {
                return p.getNome();
            }
            for (Luna l : p.getLune()) {
                if (l.getId().equals(id)) {
                    return l.getNome();
                }
            }
        }
        return "Sconosciuto";
    }

    public Object ottieniAstro(String id) {
        if (id.equals(this.id)) {
            return this;
        }

        for (Pianeta p : pianeti) {
            if (p.getId().equals(id)) {
                return p;
            }
            for (Luna l : p.getLune()) {
                if (l.getId().equals(id)) {
                    return l;
                }
            }
        }
        return null;
    }
}