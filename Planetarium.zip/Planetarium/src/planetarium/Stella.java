package planetarium;

import java.util.ArrayList;

/**
 * Classe che rappresenta una stella in un sistema planetario.
 * Contiene informazioni sulla stella e gestisce i pianeti che le orbitano attorno.
 */
public class Stella {
    private double massa;
    private int posizioneX;
    private int posizioneY;
    private String id;
    private String nome;
    private ArrayList<Pianeta> pianeti = new ArrayList<>();

    /**
     * Restituisce l'ID della stella
     * @return l'ID della stella
     */
    public String getId() { return id; }

    /**
     * Imposta l'ID della stella
     * @param id il nuovo ID da impostare
     */
    public void setId(String id) { this.id = id; }

    /**
     * Restituisce il nome della stella
     * @return il nome della stella
     */
    public String getNome() { return nome; }

    /**
     * Imposta il nome della stella
     * @param nome il nuovo nome da impostare
     */
    public void setNome(String nome) { this.nome = nome; }

    /**
     * Restituisce la massa della stella
     * @return la massa della stella
     */
    public double getMassa() { return massa; }

    /**
     * Imposta la massa della stella
     * @param massa la nuova massa da impostare
     */
    public void setMassa(double massa) { this.massa = massa; }

    /**
     * Restituisce la posizione della stella come stringa formattata
     * @return stringa con le coordinate (X, Y)
     */
    public String getPosizione() {
        return "( " + posizioneX + ", " + posizioneY + " )";
    }

    /**
     * Imposta la posizione della stella
     * @param x coordinata X
     * @param y coordinata Y
     */
    public void setPosizione(int x, int y) {
        this.posizioneX = x;
        this.posizioneY = y;
    }

    /**
     * Restituisce la coordinata X della stella
     * @return coordinata X
     */
    public int getPosizioneX() { return posizioneX; }

    /**
     * Restituisce la coordinata Y della stella
     * @return coordinata Y
     */
    public int getPosizioneY() { return posizioneY; }

    /**
     * Imposta la coordinata X della stella
     * @param x nuova coordinata X
     */
    public void setPosizioneX(int x) { this.posizioneX = x; }

    /**
     * Imposta la coordinata Y della stella
     * @param y nuova coordinata Y
     */
    public void setPosizioneY(int y) { this.posizioneY = y; }

    /**
     * Restituisce la lista dei pianeti orbitanti
     * @return ArrayList di Pianeta
     */
    public ArrayList<Pianeta> getPianeti() { return pianeti; }

    /**
     * Imposta la lista dei pianeti orbitanti
     * @param pianeti nuova lista di pianeti
     */
    public void setPianeti(ArrayList<Pianeta> pianeti) { this.pianeti = pianeti; }

    /**
     * Costruttore completo per la stella
     * @param massa massa della stella
     * @param posizioneX coordinata X
     * @param posizioneY coordinata Y
     * @param id identificativo univoco
     * @param nome nome della stella
     * @param pianeti lista di pianeti orbitanti
     */
    public Stella(float massa, int posizioneX, int posizioneY, String id, String nome, ArrayList<Pianeta> pianeti) {
        this.massa = massa;
        this.posizioneX = posizioneX;
        this.posizioneY = posizioneY;
        this.id = id;
        this.nome = nome;
        this.pianeti = pianeti;
    }

    /**
     * Costruttore vuoto che inizializza la lista dei pianeti
     */
    public Stella() {
        this.pianeti = new ArrayList<>();
    }

    /**
     * Override del metodo toString per la rappresentazione testuale della stella
     * @return stringa descrittiva della stella
     */
    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("Stella: ").append(nome)
                .append(" (").append(id).append(")")
                .append(", Massa: ").append(massa)
                .append(", Posizione: (").append(posizioneX)
                .append(", ").append(posizioneY).append(")")
                .append(", Pianeti orbitanti: [");

        if (!pianeti.isEmpty()) {
            for (int i = 0; i < pianeti.size(); i++) {
                if (i > 0) {
                    sb.append(", ");
                }
                sb.append(pianeti.get(i).getId());
            }
        } else {
            sb.append("Nessun pianeta");
        }

        sb.append("]");
        return sb.toString();
    }

    /**
     * Aggiunge un pianeta alla stella
     * @param pianeta il pianeta da aggiungere
     * @return true se l'aggiunta è avvenuta con successo, false altrimenti
     */
    public boolean aggiungiPianeta(Pianeta pianeta) {
        if (pianeti.size() >= 26000) {
            return false;
        }
        if (pianeta != null && !pianeti.contains(pianeta)) {
            String idPianeta = this.nome.substring(0, Math.min(3, this.nome.length())).toUpperCase()
                    + "PI" + (pianeti.size() + 1);
            pianeta.setId(idPianeta);
            pianeti.add(pianeta);
            return true;
        }
        return false;
    }

    /**
     * Aggiunge una luna a un pianeta specifico
     * @param codicePianeta ID del pianeta a cui aggiungere la luna
     * @param luna la luna da aggiungere
     * @return true se l'aggiunta è avvenuta con successo, false altrimenti
     */
    public boolean aggiungiLuna(String codicePianeta, Luna luna) {
        for (Pianeta p : pianeti) {
            if (p.getId().equals(codicePianeta)) {
                return p.aggiungiLuna(luna);
            }
        }
        return false;
    }

    /**
     * Rimuove un pianeta dal sistema
     * @param idPianeta ID del pianeta da rimuovere
     */
    public void rimuoviPianeta(String idPianeta) {
        for (int i = 0; i < pianeti.size(); i++) {
            if (pianeti.get(i).getId().equals(idPianeta)) {
                pianeti.remove(i);
                return;
            }
        }
        System.out.println("Nessun pianeta trovato con ID: " + idPianeta);
    }

    /**
     * Rimuove una luna da un pianeta specifico
     * @param idPianeta ID del pianeta da cui rimuovere la luna
     * @param idLuna ID della luna da rimuovere
     */
    public void rimuoviLuna(String idPianeta, String idLuna) {
        for (Pianeta p : pianeti) {
            if (p.getId().equals(idPianeta)) {
                for (int j = 0; j < p.getLune().size(); j++) {
                    if (p.getLune().get(j).getId().equals(idLuna)) {
                        p.getLune().remove(j);
                        return;
                    }
                }
            }
        }
        System.out.println("Nessuna luna trovata con ID: " + idLuna + " per il pianeta: " + idPianeta);
    }

    /**
     * Calcola e stampa il centro di massa del sistema
     */
    public void centroDiMassa() {
        double sommaMassa = massa;
        double sommaPosizioneX = posizioneX * massa;
        double sommaPosizioneY = posizioneY * massa;

        for (Pianeta pianeta : pianeti) {
            sommaMassa += pianeta.getMassa();
            sommaPosizioneX += (pianeta.getMassa() * pianeta.getPosizioneX());
            sommaPosizioneY += (pianeta.getMassa() * pianeta.getPosizioneY());

            for (Luna luna : pianeta.getLune()) {
                sommaMassa += luna.getMassa();
                sommaPosizioneX += (luna.getMassa() * luna.getPosizioneX());
                sommaPosizioneY += (luna.getMassa() * luna.getPosizioneY());
            }
        }

        double centroX = sommaPosizioneX / sommaMassa;
        double centroY = sommaPosizioneY / sommaMassa;
        System.out.println("Il centro di massa e': (" + centroX + ", " + centroY + ")");
    }

    /**
     * Verifica possibili collisioni tra gli astri del sistema
     */
    public void verificaCollisioni() {
        // Collisioni tra pianeti
        colPianeti();

        // Collisioni tra lune dello stesso pianeta
        for (Pianeta p : pianeti) {
            colLune(p);
        }

        // Collisioni tra lune di pianeti diversi
        colPianetaLuna();
    }

    /**
     * Verifica collisioni tra pianeti
     */
    private void colPianeti() {
        for (int i = 0; i < pianeti.size(); i++) {
            for (int j = i + 1; j < pianeti.size(); j++) {
                Pianeta p1 = pianeti.get(i);
                Pianeta p2 = pianeti.get(j);
                if (Math.abs(p1.getRaggio() - p2.getRaggio()) < 0.001) {
                    System.out.println("[COLLISIONE] Pianeti " + p1.getNome() +
                            " e " + p2.getNome() + " hanno lo stesso raggio orbitale!");
                }
            }
        }
    }

    /**
     * Verifica collisioni tra lune dello stesso pianeta
     * @param pianeta il pianeta di cui verificare le lune
     */
    private void colLune(Pianeta pianeta) {
        ArrayList<Luna> lune = pianeta.getLune();
        for (int i = 0; i < lune.size(); i++) {
            for (int j = i + 1; j < lune.size(); j++) {
                Luna l1 = lune.get(i);
                Luna l2 = lune.get(j);
                if (Math.abs(l1.getRaggio() - l2.getRaggio()) < 0.001) {
                    System.out.println("[COLLISIONE] Lune " + l1.getNome() +
                            " e " + l2.getNome() + " orbitano alla stessa distanza!");
                }
            }
        }
    }

    /**
     * Verifica collisioni tra lune e pianeti diversi
     */
    private void colPianetaLuna() {
        for (Pianeta p : pianeti) {
            for (Luna l : p.getLune()) {
                double[] corona = l.calcolaCoronaCircolare();
                for (Pianeta altroP : pianeti) {
                    if (!p.equals(altroP) &&
                            altroP.getRaggio() >= corona[0] &&
                            altroP.getRaggio() <= corona[1]) {
                        System.out.println("[COLLISIONE] La luna " + l.getNome() +
                                " del pianeta " + p.getNome() +
                                " potrebbe collidere con il pianeta " + altroP.getNome());
                    }
                }
            }
        }
    }

    /**
     * Verifica se un astro esiste nel sistema
     * @param id L'identificativo dell'astro da cercare
     * @return true se l'astro è stato trovato, false altrimenti
     */
    public boolean ricercaAstro(String id) {
        if (id == null || id.length() < 5) return false;

        String tipo = id.substring(3, 5);

        if (tipo.equals("PI")) {
            for (Pianeta p : pianeti) {
                if (p.getId().equals(id)) return true;
            }
        }
        else if (tipo.equals("LU")) {
            String prefissoPianeta = id.substring(0, 3);
            for (Pianeta p : pianeti) {
                if (p.getId().startsWith(prefissoPianeta)) {
                    for (Luna l : p.getLune()) {
                        if (l.getId().equals(id)) return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Stampa le informazioni di un astro
     * @param id ID dell'astro da stampare
     * @return stringa con le informazioni dell'astro o messaggio di errore
     */
    public String stampaAstro(String id) {
        if (!ricercaAstro(id)) return "Nessun astro trovato con ID: " + id;

        String tipo = id.substring(3, 5);
        String prefissoPianeta = id.substring(0, 3);

        if (tipo.equals("PI")) {
            for (Pianeta p : pianeti) {
                if (p.getId().equals(id)) return p.toString();
            }
        }
        else if (tipo.equals("LU")) {
            for (Pianeta p : pianeti) {
                if (p.getId().startsWith(prefissoPianeta)) {
                    for (Luna l : p.getLune()) {
                        if (l.getId().equals(id)) return l.toString();
                    }
                }
            }
        }
        return "ID non valido";
    }

    /**
     * Calcola una rotta tra due astri (non implementato)
     * @param idPartenza ID dell'astro di partenza
     * @param idArrivo ID dell'astro di arrivo
     */
    public void calcolaRotta(String idPartenza, String idArrivo) {
        // Implementazione futura
    }

    /**
     * Trova il pianeta padre di una luna
     * @param idLuna ID della luna
     * @return ID del pianeta padre o null se non trovato
     */
    private String getPianetaPadre(String idLuna) {
        for (Pianeta p : pianeti) {
            for (Luna l : p.getLune()) {
                if (l.getId().equals(idLuna)) {
                    return p.getId();
                }
            }
        }
        return null;
    }

    /**
     * Calcola la distanza tra due astri
     * @param id1 ID del primo astro
     * @param id2 ID del secondo astro
     * @return distanza tra i due astri
     */
    private double calcolaDistanza(String id1, String id2) {
        // Se uno dei due è la stella centrale
        if (id1.equals(this.id)) {
            return distanzaDallaStella(id2);
        }
        if (id2.equals(this.id)) {
            return distanzaDallaStella(id1);
        }

        // Se entrambi sono lune
        if (id1.substring(3, 5).equals("LU") && id2.substring(3, 5).equals("LU")) {
            Luna luna1 = (Luna)ottieniAstro(id1);
            Luna luna2 = (Luna)ottieniAstro(id2);
            return Math.abs(luna1.getRaggio() - luna2.getRaggio());
        }

        return 1.0; // Valore di default
    }

    /**
     * Calcola la distanza di un astro dalla stella
     * @param idAstro ID dell'astro
     * @return distanza dalla stella
     */
    private double distanzaDallaStella(String idAstro) {
        Object astro = ottieniAstro(idAstro);
        if (astro instanceof Pianeta) {
            return ((Pianeta)astro).getRaggio();
        } else if (astro instanceof Luna) {
            return ((Luna)astro).getCorona();
        }
        return 0.0;
    }

    /**
     * Restituisce il nome di un astro dato il suo ID
     * @param id ID dell'astro
     * @return nome dell'astro o "Sconosciuto" se non trovato
     */
    private String stampaNome(String id) {
        if (id.equals(this.id)) {
            return this.nome;
        }

        for (Pianeta p : pianeti) {
            if (p.getId().equals(id)) {
                return p.getNome();
            }
            for (Luna l : p.getLune()) {
                if (l.getId().equals(id)) {
                    return l.getNome();
                }
            }
        }
        return "Sconosciuto";
    }

    /**
     * Ottiene un astro dato il suo ID
     * @param id ID dell'astro da cercare
     * @return l'oggetto astro (Stella, Pianeta o Luna) o null se non trovato
     */
    public Object ottieniAstro(String id) {
        if (id.equals(this.id)) {
            return this;
        }

        for (Pianeta p : pianeti) {
            if (p.getId().equals(id)) {
                return p;
            }
            for (Luna l : p.getLune()) {
                if (l.getId().equals(id)) {
                    return l;
                }
            }
        }
        return null;
    }
}